import { useState, useMemo, useCallback, useRef, useEffect } from 'react';

interface BarPendulumConfig {
  barLength?: number;         // L in meters (e.g., 1.0)
  gravity?: number;          // g in m/s^2 (default: 9.81)
  initialAngle?: number;     // Starting amplitude in radians
  dampingCoeff?: number;     // Damping coefficient γ (default: 0.03)
}

/**
 * Full nonlinear bar pendulum simulation using RK4 integration.
 *
 * Equation of motion for a compound (bar) pendulum:
 *   θ'' = -(g·l / (k² + l²)) · sin(θ) - γ · θ'
 *
 * where:
 *   l  = distance from pivot to centre of gravity
 *   k² = L²/12  (radius of gyration squared for a uniform bar)
 *   γ  = viscous damping coefficient
 *
 * The state vector is [θ, ω] where ω = dθ/dt.
 * We advance the state with a fixed-step RK4 integrator so the motion
 * is smooth, frame-rate-independent, and physically accurate even for
 * large amplitudes.
 */
export const useBarPendulum = ({
  barLength = 1.0,
  gravity = 9.81,
  initialAngle = Math.PI / 12,
  dampingCoeff = 0.03,
}: BarPendulumConfig = {}) => {
  const [selectedHole, setSelectedHole] = useState<number>(2);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  // elapsedTime in state is the authoritative snapshot — synced on pause & periodically
  const [elapsedTime, setElapsedTime] = useState<number>(0);

  // ──── refs that drive the simulation at full frame rate without re-renders ────
  /** Current angle in radians — read by the rendering component via ref */
  const angleRef = useRef<number>(0);
  /** Internal integrator state */
  const thetaRef = useRef<number>(initialAngle);
  const omegaRef = useRef<number>(0); // angular velocity
  /** Total simulated time */
  const simTimeRef = useRef<number>(0);
  /** Timestamp of the last rAF callback */
  const lastFrameRef = useRef<number>(0);
  const rafIdRef = useRef<number>(0);
  /** DOM element ref for the stopwatch — updated every frame directly */
  const stopwatchElRef = useRef<HTMLElement | null>(null);

  // ──── derived physics constants (recomputed when hole changes) ────
  const physicsData = useMemo(() => {
    const holeSpacingMeters = 0.05; // 5 cm
    const distanceFromTopMeters = selectedHole * holeSpacingMeters;
    const cgPositionMeters = barLength / 2; // 0.50 m

    const signedDistanceFromCG = distanceFromTopMeters - cgPositionMeters;
    const pivotDistanceL = Math.abs(signedDistanceFromCG);

    // k² = L²/12 for a uniform bar
    const kSquared = Math.pow(barLength, 2) / 12;

    let timePeriod = Infinity;
    if (pivotDistanceL > 0.001) {
      timePeriod =
        2 *
        Math.PI *
        Math.sqrt(
          (kSquared + Math.pow(pivotDistanceL, 2)) /
            (gravity * pivotDistanceL),
        );
    }

    const measuredTime20 =
      timePeriod === Infinity
        ? Infinity
        : Math.round(timePeriod * 20 * 100) / 100;

    // Effective angular frequency for the linearised case (display/reference)
    const omega =
      timePeriod === Infinity ? 0 : (2 * Math.PI) / timePeriod;

    // Precompute the acceleration coefficient  α = g·l / (k² + l²)
    const accelCoeff =
      pivotDistanceL > 0.001
        ? (gravity * pivotDistanceL) / (kSquared + Math.pow(pivotDistanceL, 2))
        : 0;

    return {
      kSquared,
      signedDistanceFromCG,
      pivotDistanceL,
      timePeriod,
      measuredTime20,
      omega,
      accelCoeff,
    };
  }, [barLength, selectedHole, gravity]);

  // Keep ref copies so the rAF loop never sees stale values
  const accelCoeffRef = useRef(physicsData.accelCoeff);
  accelCoeffRef.current = physicsData.accelCoeff;
  const dampingRef = useRef(dampingCoeff);
  dampingRef.current = dampingCoeff;
  const isRunningRef = useRef(isRunning);
  isRunningRef.current = isRunning;

  // ──── RK4 integrator ────
  const step = useCallback(
    (theta: number, omega: number, dt: number): [number, number] => {
      const alpha = accelCoeffRef.current;
      const gamma = dampingRef.current;

      const f = (th: number, w: number): [number, number] => [
        w,
        -alpha * Math.sin(th) - gamma * w,
      ];

      const [k1t, k1w] = f(theta, omega);
      const [k2t, k2w] = f(theta + (dt / 2) * k1t, omega + (dt / 2) * k1w);
      const [k3t, k3w] = f(theta + (dt / 2) * k2t, omega + (dt / 2) * k2w);
      const [k4t, k4w] = f(theta + dt * k3t, omega + dt * k3w);

      const newTheta = theta + (dt / 6) * (k1t + 2 * k2t + 2 * k3t + k4t);
      const newOmega = omega + (dt / 6) * (k1w + 2 * k2w + 2 * k3w + k4w);

      return [newTheta, newOmega];
    },
    [],
  );

  // ──── animation loop — runs continuously at native refresh rate ────
  const animate = useCallback(
    (timestamp: number) => {
      if (lastFrameRef.current !== 0) {
        const dtReal = (timestamp - lastFrameRef.current) / 1000;
        // Clamp to avoid spiral-of-death when tab is backgrounded
        const dtClamped = Math.min(dtReal, 0.05);

        if (isRunningRef.current && accelCoeffRef.current > 0) {
          // Sub-step the integrator at a fixed 1ms step for stability
          const FIXED_DT = 0.001;
          let remaining = dtClamped;

          while (remaining > 0) {
            const h = Math.min(FIXED_DT, remaining);
            const [newTheta, newOmega] = step(
              thetaRef.current,
              omegaRef.current,
              h,
            );
            thetaRef.current = newTheta;
            omegaRef.current = newOmega;
            remaining -= h;
          }

          simTimeRef.current += dtClamped;
          angleRef.current = thetaRef.current;

          // Update the stopwatch DOM element directly — no React re-render
          if (stopwatchElRef.current) {
            stopwatchElRef.current.textContent = simTimeRef.current.toFixed(2);
          }
        }
      }
      lastFrameRef.current = timestamp;
      rafIdRef.current = requestAnimationFrame(animate);
    },
    [step],
  );

  useEffect(() => {
    rafIdRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafIdRef.current);
  }, [animate]);

  // ──── public API ────
  const getCurrentAngle = useCallback(() => {
    return angleRef.current;
  }, []);

  const toggleSimulation = useCallback(() => {
    setIsRunning((prev) => {
      if (prev) {
        // Pausing — snapshot the exact sim time into React state for logging
        setElapsedTime(simTimeRef.current);
      }
      return !prev;
    });
  }, []);

  const resetSimulation = useCallback(() => {
    setIsRunning(false);
    thetaRef.current = initialAngle;
    omegaRef.current = 0;
    simTimeRef.current = 0;
    angleRef.current = 0;
    lastFrameRef.current = 0;
    setElapsedTime(0);
    // Clear stopwatch display immediately
    if (stopwatchElRef.current) {
      stopwatchElRef.current.textContent = '0.00';
    }
  }, [initialAngle]);

  // Provide a tickTime no-op so existing callers don't break
  const tickTime = useCallback((_delta: number) => {}, []);

  return {
    selectedHole,
    setSelectedHole,
    metrics: physicsData,
    simulationState: {
      isRunning,
      elapsedTime,
      toggleSimulation,
      resetSimulation,
      getCurrentAngle,
      tickTime,
      angleRef,          // direct ref for jank-free bar rendering
      stopwatchElRef,    // direct ref for jank-free stopwatch rendering
      simTimeRef,        // live sim time for accurate logging at any moment
    },
  };
};
